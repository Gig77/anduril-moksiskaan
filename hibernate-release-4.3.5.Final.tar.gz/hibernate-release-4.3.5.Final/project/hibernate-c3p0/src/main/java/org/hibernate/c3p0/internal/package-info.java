/**
 * Implementation of ConnectionProvider using the c3p0 Connection pool.
 */
package org.hibernate.c3p0.internal;
