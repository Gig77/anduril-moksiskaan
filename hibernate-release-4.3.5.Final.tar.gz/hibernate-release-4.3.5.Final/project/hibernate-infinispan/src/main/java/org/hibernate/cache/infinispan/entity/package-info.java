/**
 * Internal Infinispan-based implementation of the entity cache region
 */
package org.hibernate.cache.infinispan.entity;
