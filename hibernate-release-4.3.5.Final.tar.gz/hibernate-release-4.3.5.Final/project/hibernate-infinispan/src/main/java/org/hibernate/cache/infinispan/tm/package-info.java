/**
 * Internal bridging between Infinispan and Hibernate notions of talking to JTA
 */
package org.hibernate.cache.infinispan.tm;
