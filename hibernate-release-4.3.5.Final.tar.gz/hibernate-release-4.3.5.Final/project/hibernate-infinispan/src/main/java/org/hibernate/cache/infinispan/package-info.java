/**
 * Defines the integration with Infinispan as a second-level cache service.
 */
package org.hibernate.cache.infinispan;
