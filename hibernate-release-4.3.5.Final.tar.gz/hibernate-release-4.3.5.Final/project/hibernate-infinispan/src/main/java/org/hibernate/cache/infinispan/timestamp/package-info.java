/**
 * Internal Infinispan-based implementation of the "update timestamps" cache region
 */
package org.hibernate.cache.infinispan.timestamp;
