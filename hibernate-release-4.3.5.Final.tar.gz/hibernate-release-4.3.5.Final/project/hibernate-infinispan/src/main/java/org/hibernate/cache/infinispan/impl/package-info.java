/**
 * Internal Infinispan-specific base cache region implementations
 */
package org.hibernate.cache.infinispan.impl;
