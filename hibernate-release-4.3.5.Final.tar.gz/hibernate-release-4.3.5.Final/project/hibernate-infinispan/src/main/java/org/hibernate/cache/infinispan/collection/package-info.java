/**
 * Internal Infinispan-based implementation of the collection cache region
 */
package org.hibernate.cache.infinispan.collection;
