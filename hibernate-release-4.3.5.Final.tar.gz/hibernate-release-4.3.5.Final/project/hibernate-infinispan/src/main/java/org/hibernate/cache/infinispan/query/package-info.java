/**
 * Internal Infinispan-based implementation of the "query results" cache region
 */
package org.hibernate.cache.infinispan.query;
