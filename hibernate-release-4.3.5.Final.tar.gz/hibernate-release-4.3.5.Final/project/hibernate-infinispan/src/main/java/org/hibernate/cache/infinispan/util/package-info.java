/**
 * Internal utilities for the Infinispan integration
 */
package org.hibernate.cache.infinispan.util;
