/**
 * Internal Infinispan-based implementation of the natural-id cache region
 */
package org.hibernate.cache.infinispan.naturalid;
