/**
 * Internal Infinispan-based implementation of the cache region access strategies
 */
package org.hibernate.cache.infinispan.access;
