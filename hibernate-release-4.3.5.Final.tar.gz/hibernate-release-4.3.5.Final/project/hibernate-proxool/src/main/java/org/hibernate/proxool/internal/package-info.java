/**
 * Implementation of ConnectionProvider using the proxool Connection pool.
 */
package org.hibernate.proxool.internal;
