/**
 * Support for handling non-stop caches.  Really no idea.  The Ehcache guys added this and tbh I really do not
 * understand the intent
 */
package org.hibernate.cache.ehcache.internal.nonstop;
