/**
 * Defines {@link org.hibernate.cache.spi.access.RegionAccessStrategy} support for the Ehcache integration
 */
package org.hibernate.cache.ehcache.internal.strategy;
