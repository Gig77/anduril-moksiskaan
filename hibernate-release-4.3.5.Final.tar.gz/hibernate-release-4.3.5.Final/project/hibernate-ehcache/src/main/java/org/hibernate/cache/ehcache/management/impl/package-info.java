/**
 * Defines JMX support for the Ehcache integration
 */
package org.hibernate.cache.ehcache.management.impl;
