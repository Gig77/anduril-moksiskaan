/**
 * Defines {@link org.hibernate.cache.spi.RegionFactory} support for the Ehcache integration
 */
package org.hibernate.cache.ehcache.internal.regions;
