/**
 * Defines the integration with Ehcache as a second-level cache service.
 */
package org.hibernate.cache.ehcache;
