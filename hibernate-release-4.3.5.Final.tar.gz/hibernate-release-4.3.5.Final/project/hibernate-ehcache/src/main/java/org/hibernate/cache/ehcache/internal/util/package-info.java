/**
 * Defines utilities used by the Ehcache integration
 */
package org.hibernate.cache.ehcache.internal.util;
